// let array1 = [
//   {
//     name: "name2",
//     value: 3,
//     extravalue: "ddafdaf2",
//   },
//   {
//     name: "name3",
//     value: 2,
//     extravalue: "ddafdaf3",
//   },
//   {
//     name: "name4",
//     value: 4,
//     extravalue: "ddafdaf4",
//   },
// ];

// let array2 = [
//   {
//     name: "name4",
//     value: 1,
//     extravalue: "ddafdaf4",
//   },
//   {
//     name: "name3",
//     value: 3,
//     extravalue: "ddafdaf3",
//   },
//   {
//     name: "name5",
//     value: 6,
//     extravalue: "ddafdaf5",
//   },
// ];

// let merge = array1.concat(array2);

// const uniqueObjects = {};

// // Iterate through the original array
// merge.forEach((obj) => {
//   // Use 'id' as the unique key
//   const id = obj.name;

//   if (uniqueObjects[id]) {
//     // If the object already exists, add the values
//     uniqueObjects[id].value += obj.value;
//   } else {
//     // If the object doesn't exist, create a new one
//     uniqueObjects[id] = { id, value: obj.value, ...obj };
//   }
// });

// // Convert the uniqueObjects object back to an array
// const resultArray = Object.values(uniqueObjects);
// console.log(resultArray);

// if (items !== undefined) {
//   console.log(`i been fired`);
//   let merged = temp.concat(items);

//   const uniqueObjects = {};

//   // Iterate through the original array
//   merged.forEach((obj) => {
//     // Use 'id' as the unique key
//     const id = obj.title;

//     if (uniqueObjects[id]) {
//       // If the object already exists, add the values
//       uniqueObjects[id].quantity += obj.quantity;
//     } else {
//       // If the object doesn't exist, create a new one
//       uniqueObjects[id] = { id, ...obj };
//     }
//   });

//   // Convert the uniqueObjects object back to an array
//   const resultArray = Object.values(uniqueObjects);
//   fetch(`http://localhost:3000/api/cart/${_id}`, {
//     method: "PUT",
//     body: JSON.stringify({
//       userId: session?.user.id,
//       items: resultArray,
//       currency: {
//         name: name,
//         rate: rate,
//       },
//     }),
//   });

//   localStorage.removeItem("cartNotLogin");
// }

// {
//   dispatch(
//     changeArray({
//       userId: session?.user.id,
//       items: temp,
//       currency: {
//         name: name,
//         rate: rate,
//       },
//     })
//   );
//   fetch("/api/cart/new", {
//     method: "POST",
//     body: JSON.stringify({
//       userId: session?.user.id,
//       items: temp,
//       currency: {
//         name: name,
//         rate: rate,
//       },
//     }),
//   });
//   localStorage.removeItem("cartNotLogin");
//   dispatch(setCounter(temp.length));
// }
// if (
//   localStorage.getItem("cartNotLogIn") !== null &&
//   items !== undefined
// ) {
//   let merged = temp.concat(items);
//   const uniqueObjects = {};
//   // Iterate through the original array
//   merged.forEach((obj) => {
//     // Use 'id' as the unique key
//     const id = obj.title;
//     if (uniqueObjects[id]) {
//       // If the object already exists, add the values
//       uniqueObjects[id].quantity += obj.quantity;
//     } else {
//       // If the object doesn't exist, create a new one
//       uniqueObjects[id] = { id, ...obj };
//     }
//   });
//   // Convert the uniqueObjects object back to an array
//   const resultArray = Object.values(uniqueObjects);
//   fetch(`http://localhost:3000/api/cart/${_id}`, {
//     method: "PUT",
//     body: JSON.stringify({
//       userId: session?.user.id,
//       items: resultArray,
//       currency: {
//         name: name,
//         rate: rate,
//       },
//     }),
//   });
//   localStorage.removeItem("cartNotLogin");
// }

const arrObj1 = [
  {
    currency: {
      name: "USD",
      rate: 1.079559,
    },
    _id: "651286929ccf758ef0fb9492",
    creator: {
      _id: "64ecba6139fdd11bb2f2ab62",
      email: "earl0bluesky142226@gmail.com",
      username: "earlbutlay",
      image:
        "https://lh3.googleusercontent.com/a/AAcHTtfEUW3BbdkEz1ecmoDCqfAjq8iWzvJr4Fvsj8kyucYmfA=s96-c",
      __v: 0,
    },
    items: [
      {
        title: "iPhone 9",
        description: "An apple mobile which is nothing like apple",
        price: 549,
        quantity: 1,
        discountPercentage: 12.96,
        thumbnail: "https://i.dummyjson.com/data/products/1/thumbnail.jpg",
        rating: 4.69,
        stock: 94,
        brand: "Apple",
        category: "smartphones",
        images: [],
        _id: "651286929ccf758ef0fb9493",
      },
    ],
    __v: 0,
  },
];

const arrObj2 = [
  {
    currency: {
      name: "USD",
      rate: 1.079559,
    },
    _id: "65127fe99ccf758ef0fb93d2",
    creator: {
      _id: "64ecba6139fdd11bb2f2ab62",
      email: "earl0bluesky142226@gmail.com",
      username: "earlbutlay",
      image:
        "https://lh3.googleusercontent.com/a/AAcHTtfEUW3BbdkEz1ecmoDCqfAjq8iWzvJr4Fvsj8kyucYmfA=s96-c",
      __v: 0,
    },
    items: [
      {
        title: "iPhone 9",
        description: "An apple mobile which is nothing like apple",
        price: 549,
        quantity: 1,
        discountPercentage: 12.96,
        thumbnail: "https://i.dummyjson.com/data/products/1/thumbnail.jpg",
        rating: 4.69,
        stock: 94,
        brand: "Apple",
        category: "smartphones",
        images: [],
        _id: "65127fcc9ccf758ef0fb93ca",
      },
    ],
    timestamp: 1695711208668,
    __v: 0,
  },
  {
    currency: {
      name: "USD",
      rate: 1.079559,
    },
    _id: "651280279ccf758ef0fb93ed",
    creator: {
      _id: "64ecba6139fdd11bb2f2ab62",
      email: "earl0bluesky142226@gmail.com",
      username: "earlbutlay",
      image:
        "https://lh3.googleusercontent.com/a/AAcHTtfEUW3BbdkEz1ecmoDCqfAjq8iWzvJr4Fvsj8kyucYmfA=s96-c",
      __v: 0,
    },
    items: [
      {
        title: "iPhone 9",
        description: "An apple mobile which is nothing like apple",
        price: 549,
        quantity: 1,
        discountPercentage: 12.96,
        thumbnail: "https://i.dummyjson.com/data/products/1/thumbnail.jpg",
        rating: 4.69,
        stock: 94,
        brand: "Apple",
        category: "smartphones",
        images: [],
        _id: "651280199ccf758ef0fb93d9",
      },
      {
        title: "iPhone X",
        description:
          "SIM-Free, Model A19211 6.5-inch Super Retina HD display with OLED technology A12 Bionic chip with ...",
        price: 899,
        quantity: 1,
        discountPercentage: 17.94,
        thumbnail: "https://i.dummyjson.com/data/products/2/thumbnail.jpg",
        rating: 4.44,
        stock: 34,
        brand: "Apple",
        category: "smartphones",
        images: [],
        _id: "651280209ccf758ef0fb93e2",
      },
    ],
    timestamp: 1695711271443,
    __v: 0,
  },
];

let merged = arrObj1.concat(arrObj2);

// console.log(merged);
merged.forEach((obj) => {
  console.log(obj.items.title);
});
