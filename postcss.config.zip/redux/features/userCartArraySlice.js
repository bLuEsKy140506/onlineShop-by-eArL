import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

export const fetchCartArray = createAsyncThunk("fetchCartArray", async (id) => {
  const res = await fetch(`http://localhost:3000/api/userss/${id}/cart`, {
    cache: "no-store",
  });
  let response = res.json();
  return response;
});

const initialRate = { name: "USD", rate: 1.056832 };
const initialState = [];
export const cartArray = createSlice({
  name: "cartArray",
  initialState: initialState,
  reducers: {
    changeArray(state, action) {
      state = action.payload;
      return state;
    },
  },

  extraReducers: (builder) => {
    builder.addCase(fetchCartArray.fulfilled, (state, action) => {
      let temp = JSON.parse(localStorage.getItem("cartNotLogIn"));

      if (temp !== null && action.payload[0] !== undefined) {
        let merged = temp.concat(action.payload[0].items);

        const uniqueObjects = {};
        merged.forEach((obj) => {
          // Use 'id' as the unique key
          const id = obj.title;
          if (uniqueObjects[id]) {
            // If the object already exists, add the values
            uniqueObjects[id].quantity += obj.quantity;
          } else {
            // If the object doesn't exist, create a new one
            uniqueObjects[id] = { ...obj };
          }
        });

        const resultArray = Object.values(uniqueObjects);

        fetch(
          `http://localhost:3000/api/cart/${action.payload[0]._id.toString()}`,
          {
            method: "PUT",
            body: JSON.stringify({
              creator: action.payload[0].creator._id.toString(),
              items: resultArray,
              currency: action.payload[0].currency,
            }),
          }
        );

        state = [
          {
            _id: action.payload[0].creator._id.toString(),
            items: resultArray,
            currency: action.payload[0].currency,
          },
        ];
        localStorage.removeItem("cartNotLogIn");
        return state;
      } else if (action.payload[0] !== undefined && temp === null) {
        state = action.payload[0];
        localStorage.removeItem("cartNotLogIn");

        return state;
      } else if (temp !== null && action.payload[0] === undefined) {
        fetch("http://localhost:3000/api/cart/new", {
          method: "POST",
          body: JSON.stringify({
            userId: action.meta.arg.toString(),
            items: temp,
            currency: initialRate,
          }),
        });
        state = [
          {
            creator: action.meta.arg.toString(),
            items: temp,
            currency: {
              name: "USD",
              currency: initialRate,
            },
          },
        ];
        localStorage.removeItem("cartNotLogIn");
        return state;
      }
    });
  },
});

export const { changeArray } = cartArray.actions;
export default cartArray.reducer;
