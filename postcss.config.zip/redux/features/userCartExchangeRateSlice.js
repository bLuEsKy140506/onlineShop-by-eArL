import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

export const fetchExchangeRate = createAsyncThunk(
  "fetchExchangeRate",
  async (id) => {
    const res = await fetch(`http://localhost:3000/api/userss/${id}/cart`);
    return res.json();
  }
);

//const res = await fetch("http://data.fixer.io/api/latest?access_key=0ec2300dfadbfd2eabc14833cfce7cf8&symbols=USD,AUD,CAD,PLN,MXN,PHP&format=1");
const initialState = { name: "USD", rate: 1.056832 };
// const initialState = async () =>
//   await fetch(
//     "http://data.fixer.io/api/latest?access_key=0ec2300dfadbfd2eabc14833cfce7cf8&symbols=USD&format=1"
//   );

export const exchangeValue = createSlice({
  name: "exchangeValue",
  initialState: initialState,
  reducers: {
    changeRate(state, action) {
      state = action.payload;
      return state;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchExchangeRate.fulfilled, (state, action) => {
      if (action.payload.length === 0) {
        return state;
      } else {
        state = action.payload[0].currency;
        return state;
      }
    });
  },
});

export const { changeRate } = exchangeValue.actions;
export default exchangeValue.reducer;
