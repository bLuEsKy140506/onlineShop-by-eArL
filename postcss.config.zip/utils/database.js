import mongoose from "mongoose";

let isConnected = false; // track the connection

export const connectToDB = async () => {
  mongoose.set("strictQuery", true);
  let count = 0;
  if (isConnected) {
    count = count + 1;
    console.log("MongoDB is already connected " + count);
    return;
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      dbName: "onlineshop_database",
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    isConnected = true;

    console.log("MongoDB connected");
  } catch (error) {
    console.log(error);
  }
};
